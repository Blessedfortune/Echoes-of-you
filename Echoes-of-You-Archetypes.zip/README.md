# Echoes of You - Echo Archetypes Starter Project

This is a starter project for the next Echoes of You game buildup, focusing on the six unique Echo archetypes.

## Project Structure

- `index.html` - Multi-page introduction to each Echo archetype with navigation buttons.
- `style.css` - Basic styling for pages and navigation.
- `script.js` - JavaScript to handle page navigation logic.
- `assets/` - Placeholder folder for images, sounds, or other game assets.

## Echo Archetypes Introduced

1. The Rationalist
2. The Rebel
3. The Caregiver
4. The Shadow
5. The Dreamer
6. The Anchor

## How to Use

- Open `index.html` in a web browser to see the archetype pages.
- Use the Previous and Next buttons to navigate between archetypes.
- Expand this project by adding character art, dialogues, puzzles, and abilities.

## Next Steps

- Create illustrated characters for each archetype.
- Develop unique puzzles based on puzzle roles.
- Integrate Echo abilities into gameplay mechanics.
- Write character-driven dialogue and story arcs.
